//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by grefish.rc
//
#define IDB_GROUND                      102
#define IDB_SKY                         103
#define IDB_GRAV                        104
#define IDB_DIE                         105
#define IDB_WHAT                        106
#define IDB_BLOD                        107
#define IDB_HIGH                        108
#define IDB_FLAG                        109
#define IDB_TREE                        110
#define IDB_NOGRAV                      111
#define IDB_GASI                        112
#define IDB_BACK                        113
#define IDB_CHA                         114

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
