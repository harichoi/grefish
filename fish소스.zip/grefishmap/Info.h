#if !defined(AFX_INFO_H__0E811F07_9844_461E_B02F_1FE662703DDC__INCLUDED_)
#define AFX_INFO_H__0E811F07_9844_461E_B02F_1FE662703DDC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Info.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CInfo dialog

class CInfo : public CDialog
{
// Construction
public:
	CInfo(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CInfo)
	enum { IDD = IDD_INFO };
	double	m_py;
	double	m_px;
	double	m_pvx;
	double	m_pvy;
	double	m_mx;
	double	m_my;
	double	m_mvx;
	double	m_mvy;
	double	m_aaax;
	double	m_aaay;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInfo)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CInfo)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INFO_H__0E811F07_9844_461E_B02F_1FE662703DDC__INCLUDED_)
