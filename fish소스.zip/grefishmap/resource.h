//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by grefishmap.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GREFISHMAP_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDB_HIGH                        129
#define IDB_NOGRAV                      130
#define IDB_SKY                         131
#define IDB_TREE                        132
#define IDB_WHAT                        133
#define IDB_BACK                        134
#define IDB_BLOD                        135
#define IDB_CHA                         136
#define IDB_DIE                         137
#define IDB_FLAG                        138
#define IDB_GASI                        139
#define IDB_GRAV                        140
#define IDB_GROUND                      141
#define IDD_DELETEEFFECT                142
#define IDD_SET                         143
#define IDD_IFF                         144
#define IDD_INFO                        145
#define IDD_DIALOG1                     146
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_BUTTON5                     1004
#define IDC_BUTTON6                     1005
#define IDC_BUTTON7                     1006
#define IDC_EDIT1                       1007
#define IDC_BUTTON9                     1009
#define IDC_BUTTON11                    1011
#define IDC_BUTTON12                    1012
#define IDC_BUTTON13                    1013
#define IDC_EDIT2                       1014
#define IDC_EDIT4                       1016
#define IDC_EDIT5                       1017
#define IDC_EDIT6                       1018
#define IDC_BUTTON14                    1019
#define IDC_EDIT7                       1020
#define IDC_EDIT8                       1021
#define IDC_BUTTON8                     1022
#define IDC_BUTTON10                    1023
#define IDC_EDIT3                       1024
#define IDC_EDIT9                       1025
#define IDC_EDIT10                      1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
